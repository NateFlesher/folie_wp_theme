<?php

class Cl_Shortcode_Column extends Cl_Shortcode_Container{
    


}

?>